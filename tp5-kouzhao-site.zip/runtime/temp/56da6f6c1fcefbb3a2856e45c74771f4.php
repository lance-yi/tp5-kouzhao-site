<?php if (!defined('THINK_PATH')) exit(); /*a:5:{s:76:"D:\Github\tp5-kouzhao-site\public/../application/index\view\index\index.html";i:1589043229;s:68:"D:\Github\tp5-kouzhao-site\application\index\view\common\header.html";i:1589043227;s:68:"D:\Github\tp5-kouzhao-site\application\index\view\common\newmsg.html";i:1558958376;s:69:"D:\Github\tp5-kouzhao-site\application\index\view\common\message.html";i:1558958376;s:68:"D:\Github\tp5-kouzhao-site\application\index\view\common\footer.html";i:1558958376;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-COMPATIBLE" content="IE=edge,chrome=1"/>
    <meta name="application-name" content=""/>
    <meta name="description" content=""/>
    <meta name="keywords" content=""/>
    <meta name="viewport"
          content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no">
    <meta name="format-detection" content="telephone=no"/>
    <meta name="format-detection" content="email=no"/>
    <link rel="shortcut icon" href="" type="image/icon" sizes="16*16">
    <link rel="stylesheet" href="/static/css/Home/base.css">
    <link rel="stylesheet" href="/static/css/Home/main.css">
    <link rel="stylesheet" href="//at.alicdn.com/t/font_1176844_03wydqx0vwo8.css">
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.0.2/css/swiper.min.css"> -->

</head>

<body>
<!-- 主体 -->
<section id="app">

<article>
    <link rel="stylesheet" href="/static/css/Home/kz.css">
    <section class="sub">
        <p class="ellipsis-this xLocation">
            <a href="javascript:void(0)" title="">首页</a> &gt; <a target="_self" href="javascript:void(0)">财经</a> &gt; <a
                href="javascript:void(0)" title="">外发手工加工</a>
        </p>
    </section>
    <section class="tiezi-title">
        <h1>小项目 大财富</h1>
        <h1>一次性用品手工加工</h1>
        <h1>在家加工也可以赚钱</h1>
        <h1>公司免费供料 你生产我销售 </h1>
        <h1><script>document.write(new Date().getFullYear())</script> 年外发加工在家赚钱五星推荐</h1>
    </section>
    <section class="main-img-list">
        <img src="/static/images/Home/chabao/index_01.gif" alt="">
        <img src="/static/images/Home/chabao/index_02.gif" alt="">
        <img src="/static/images/Home/chabao/index_03.gif" alt="">
        <img src="/static/images/Home/chabao/index_04.gif" alt="">
        <img src="/static/images/Home/chabao/index_05.gif" alt="">
        <img src="/static/images/Home/chabao/index_06.gif" alt="">
        <img src="/static/images/Home/chabao/index_07.gif" alt="">
        <img src="/static/images/Home/chabao/index_08.gif" alt="">
        <img src="/static/images/Home/chabao/index_09.gif" alt="">
        <img src="/static/images/Home/chabao/index_10.gif" alt="">
        <img src="/static/images/Home/chabao/index_11.gif" alt="">
        <img src="/static/images/Home/chabao/index_12.gif" alt="">
        <img src="/static/images/Home/chabao/index_13.gif" alt="">
        <img src="/static/images/Home/chabao/index_14.gif" alt="">
        <img src="/static/images/Home/chabao/index_15.gif" alt="">
        <img src="/static/images/Home/chabao/index_16.gif" alt="">
        <img src="/static/images/Home/chabao/index_17.gif" alt="">
        <img src="/static/images/Home/chabao/index_18.gif" alt="">
        <img src="/static/images/Home/chabao/index_19.gif" alt="">
        <img src="/static/images/Home/chabao/index_20.gif" alt="">
        <img src="/static/images/Home/chabao/index_21.gif" alt="">
        <img src="/static/images/Home/chabao/index_22.gif" alt="">
        <img src="/static/images/Home/chabao/index_23.gif" alt="">
        <img src="/static/images/Home/chabao/index_24.gif" alt="">
        <img src="/static/images/Home/chabao/index_25.gif" alt="">
        <img src="/static/images/Home/chabao/index_26.gif" alt="">
        <img src="/static/images/Home/chabao/index_27.gif" alt="">
        <img src="/static/images/Home/chabao/index_28.gif" alt="">
        <img src="/static/images/Home/chabao/index_29.gif" alt="">
        <img src="/static/images/Home/chabao/index_30.gif" alt="">
        <img src="/static/images/Home/chabao/index_31.gif" alt="">
        <img src="/static/images/Home/chabao/index_32.gif" alt="">
        <img src="/static/images/Home/chabao/index_33.gif" alt="">
        <img src="/static/images/Home/chabao/index_34.gif" alt="">
        <img src="/static/images/Home/chabao/index_35.gif" alt="">
        <img src="/static/images/Home/chabao/index_36.gif" alt="">
        <img src="/static/images/Home/chabao/index_37.gif" alt="">
        <img src="/static/images/Home/chabao/index_38.gif" alt="">
        <img src="/static/images/Home/chabao/index_39.gif" alt="">
        <img src="/static/images/Home/chabao/index_40.gif" alt="">
        <img src="/static/images/Home/chabao/index_41.gif" alt="">
        <img src="/static/images/Home/chabao/index_42.gif" alt="">
        <img src="/static/images/Home/chabao/index_43.gif" alt="">
        <img src="/static/images/Home/chabao/index_44.gif" alt="">
        <img src="/static/images/Home/chabao/index_45.gif" alt="">
        <img src="/static/images/Home/chabao/index_46.gif" alt="">
        <img src="/static/images/Home/chabao/index_47.gif" alt="">
        <img src="/static/images/Home/chabao/index_48.gif" alt="">
        <img src="/static/images/Home/chabao/index_49.gif" alt="">
        <img src="/static/images/Home/chabao/index_50.gif" alt="">
    </section>

    <!--最新留言-->
<style>
    .order_smg{
        font-size: .28rem;
        margin: .2rem;
    }
</style>
<div id="demo" class="order_smg"> </div>
<script>
    const marquee = new Array(
        "<p>[最新留言]：189****9954在1分钟前申请了加工名额</p>",
        "<p>[最新留言]：138****8576在1分钟前申请了办厂的名额</p>",
        "<p>[最新留言]：156****6310在4分钟前申请了加工名额</p>",
        "<p>[最新留言]：187****2741在8分钟前申请了办厂的名额</p>",
        "<p>[最新留言]：147****3417在9分钟前申请了总代理名额</p>");
    let marqeeI = 0;
    let marqueeII = 1;

    function marqueeL() {

        if (marqeeI > (marquee.length - 1)) marqeeI = 0;
        if (marqueeII > (marquee.length - 1)) marqeeI = 0;
        marqueeII = marqeeI + 1;
        var marHTML = marquee[marqeeI] + marquee[marqueeII];
        document.getElementById("demo").innerHTML = marHTML;
        marqeeI += 1;
        marqueeII += 1;
    }
    window.setInterval("marqueeL()", 2000);
</script>
    <!-- 留言板 样式一 -->
<div class="messagebox" id="msgBox">
    <h2><i class="iconfont icon-icon_calendar"></i> 在线留言</h2>
    <div class="messagebook">
        <form action="<?php echo url('adds'); ?>" method="post" id="info">
            <div style="border: 2px solid red;padding:.4rem;border-radius:10px;">
                <p>立即留言，离成功更近！</p>
                <div class="p-input form-name">姓名&nbsp;&nbsp; <input name="name" class="text msg-input" placeholder="如：张先生" value=""
                                                        type="text"></div>
                <div class="p-input form-name">手机&nbsp;&nbsp; <input name="mobile" class="text" placeholder="如：13888888888" value=""
                                                        type="text"></div>
                <div class="p-button">
                    <input type="hidden" name="keyword" value="<?php echo $keyword; ?>"/>
                    <input type="hidden" name="plan" value="<?php echo $plan; ?>"/>
                    <input type="hidden" name="unit" value="<?php echo $unit; ?>"/>
                    <input type="hidden" name="shijian" id="shijian" placeholder=""/>
                    <script type="text/javascript">
                        window.onload = function () {
                            var nowDate = new Date();
                            var str = nowDate.getFullYear() + "-" + (nowDate.getMonth() + 1) + "-" + nowDate.getDate() + " " +
                                nowDate.getHours() + ":" + nowDate.getMinutes() + ":" + nowDate.getSeconds();
                            document.getElementById("shijian").value = str;
                        }
                    </script>
                    <button type="submit" class="button"><span>立即留言</span></button>
                </div>
            </div>
        </form>
    </div>
</div>
</article>
<!-- 底部 -->
<footer>
    <div class="last-box">
        <a href="tel:<?php echo $phone; ?>" class="last-box-phone">
            <div>
                <span><i class="iconfont icon-phone"></i></span>
                <span>联系客服</span>
            </div>
        </a>
        <a href="#msgBox" class="last-box-msg"><i class="iconfont icon-icon_calendar"></i> 留言免费获取更多资料</a>
    </div>
</footer>
<?php echo $code; ?>
</section>
</body>
<script src="/static/js/Home/adaptive.js"></script>
<script src="/static/js/Home/config.js"></script>
<script crossorigin="anonymous" integrity="sha384-qu2J8HSjv8EaYlbzBdbVeJncuCmfBqnZ4h3UIBZ9WTZ/5Wrqt0/9hofL0046NCkc"
        src="//lib.baomitu.com/zepto/1.2.0/zepto.min.js"></script>
<script>


    $(function () {

        $("#info").submit(function (e) {
            var obj = $("#info").serializeArray();
            var _flag = new Boolean(true);
            $.each(obj, function (index, item) {
                if (item.name == "name") {
                    if (item.value == "" || $.trim(item.value).length < 2 || $.trim(item.value).length > 4) {
                        alert("请输入正确的姓名");
                        _flag = false;
                        return false;
                    }
                }
                if (item.name == "mobile") {
                    if (item.value == "" || $.trim(item.value).length != 11) {
                        alert("请输入正确的手机号");
                        _flag = false;
                        return false;
                    }
                }
            });
            return _flag;
        });
    })
</script>

</html>
