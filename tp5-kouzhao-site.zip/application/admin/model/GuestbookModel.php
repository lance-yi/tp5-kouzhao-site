<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/5/15
 * Time: 19:19
 */

namespace app\admin\model;


use think\Model;

class GuestbookModel extends Model
{
    protected $table = 'guestbook';
}