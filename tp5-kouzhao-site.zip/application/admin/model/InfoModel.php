<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/5/15
 * Time: 17:18
 */

namespace app\admin\model;


use think\Model;

class InfoModel extends Model
{
    // 设置当前模型对应的完整数据表名称
    protected $table = 'info';
}