<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/5/16
 * Time: 15:30
 */

namespace app\admin\model;


use think\Model;

class UserModel extends Model
{
    protected $table = 'user';
}